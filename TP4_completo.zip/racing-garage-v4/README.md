# Racing Garage — Aplicaciones Web 1 (TP4 / Integración con JavaScript)

Tienda online ficticia de accesorios para automóviles. Sitio estático con HTML, CSS y JavaScript (ES Modules), sin librerías externas.

## Cómo probarlo en tu computadora

El sitio usa `fetch` y módulos de JavaScript, que **no funcionan abriendo el HTML con doble click** (`file://`). Hay que servirlo:

- Con la extensión **Live Server** de VS Code (click derecho en `index.html` → *Open with Live Server*), o
- Desde la carpeta del proyecto: `python -m http.server 8000` y abrir `http://localhost:8000`.

## Configuración

En `recursos/js/config.js`:

- `NUMERO_WHATSAPP`: número que recibe los pedidos y consultas (formato internacional, solo números, ej. `"5493511234567"`). Si queda vacío, WhatsApp deja elegir el contacto.
- `DESCUENTO_TRANSFERENCIA`: descuento por pagar con transferencia (`0.10` = 10 %).

## Estructura

```text
racing-garage-v4/
├── index.html, catalogo.html, producto.html, carrito.html,
│   finalizar-compra.html, confirmacion.html, contacto.html, nosotros.html
└── recursos/
    ├── css/
    │   ├── base.css          (1º) variables, reinicio y elementos HTML
    │   ├── componentes.css   (2º) botones, formularios, tarjetas, avisos
    │   └── bloques.css       (3º) estructura de página y ajustes por bloque
    ├── data/
    │   └── productos.json    datos de los productos
    ├── js/
    │   ├── config.js         rutas, número de WhatsApp, descuentos
    │   ├── productos.js      lectura del JSON con fetch + try/catch
    │   ├── carrito.js        carrito, pedido y producto elegido (localStorage)
    │   ├── pedido.js         totales, descuento y armado del pedido
    │   ├── validaciones.js   validaciones de formularios con JavaScript
    │   ├── whatsapp.js       armado y apertura del mensaje de WhatsApp
    │   ├── interfaz.js       notificaciones, indicador del carrito, estados
    │   ├── formato.js        formato de precios y escape de HTML
    │   └── catalogo.js, producto.js, carrito-vista.js,
    │       checkout.js, confirmacion.js, contacto.js, main.js   (una por página)
    └── imagenes/
```

## Cómo se cumplen los requisitos de la consigna

| Requisito | Dónde está |
|---|---|
| Filtros del catálogo | `catalogo.js`: marca y categoría (también desde la portada con `?categoria=`) |
| Proceso completo + notificación | `checkout.js` y `whatsapp.js`: el pedido se envía por WhatsApp; `interfaz.js` muestra avisos en pantalla |
| Eventos de JavaScript | `submit`, `change`, `click`, `blur` e `input` en filtros, carrito y formularios |
| ES Modules | Todas las páginas cargan `type="module"`; los scripts comparten código con `import`/`export` |
| Modularización | Un módulo por responsabilidad (ver estructura) y funciones con nombres descriptivos |
| JSON con los datos | `recursos/data/productos.json` y el objeto del pedido (`pedido.js`) |
| `fetch` | `productos.js` lee el JSON |
| `try/catch` | `productos.js` (fetch), `carrito.js` (localStorage) y `catalogo.js`/`producto.js` (muestran el error y permiten reintentar) |
| `localStorage` | Carrito, último pedido y producto elegido (`carrito.js`) |
| Render desde JSON | Catálogo, detalle, carrito y confirmación se dibujan con los datos leídos |
| Validaciones HTML y JS | HTML: `required`, `type`, `pattern`, `minlength`, `maxlength`. JS: `validaciones.js` con mensajes por campo |
| Recursos en directorios | `css/`, `js/`, `data/`, `imagenes/` |

## Publicación en Vercel

1. Subir el proyecto a un repositorio de GitHub.
2. Entrar a [vercel.com](https://vercel.com), iniciar sesión con GitHub y elegir **Add New → Project**.
3. Importar el repositorio.
4. Si el proyecto está dentro de una subcarpeta del repositorio, en **Root Directory** elegir esa carpeta (por ejemplo `tp4/Octavio Benavidez/racing-garage-v4`).
5. **Framework Preset:** *Other*. Dejar vacíos *Build Command* y *Output Directory*.
6. Click en **Deploy**. Cada `git push` a la rama principal vuelve a publicar el sitio automáticamente.
7. Probar el sitio publicado: catálogo (carga el JSON), carrito, compra y envío por WhatsApp.
