// Módulo del pedido: cálculo de totales y armado del objeto (JSON) que se guarda y se envía

import { DESCUENTO_TRANSFERENCIA } from "./config.js";
import { calcularTotal } from "./carrito.js";

export const NOMBRES_METODO_DE_PAGO = {
    tarjeta: "Tarjeta de crédito / débito",
    transferencia: "Transferencia bancaria",
    efectivo: "Efectivo contra entrega"
};

// Devuelve el descuento en pesos: solo se aplica si se paga por transferencia
function calcularDescuento(subtotal, metodoDePago) {
    if (metodoDePago === "transferencia") {
        return Math.round(subtotal * DESCUENTO_TRANSFERENCIA);
    }

    return 0;
}

// Devuelve { subtotal, descuento, envio, total } para un carrito y un método de pago
export function calcularTotales(carrito, metodoDePago) {
    const subtotal = calcularTotal(carrito);
    const descuento = calcularDescuento(subtotal, metodoDePago);

    return {
        subtotal: subtotal,
        descuento: descuento,
        envio: 0,
        total: subtotal - descuento
    };
}

// Genera un número de pedido. Ej: "RG-048213"
function generarCodigoDePedido() {
    const numero = Math.floor(Math.random() * 1000000);
    return "RG-" + String(numero).padStart(6, "0");
}

// Arma el pedido completo como un objeto, listo para guardarse con JSON.stringify
export function armarPedido(cliente, metodoDePago, carrito) {
    return {
        codigo: generarCodigoDePedido(),
        fecha: new Date().toISOString(),
        cliente: cliente,
        metodoDePago: metodoDePago,
        productos: carrito,
        totales: calcularTotales(carrito, metodoDePago)
    };
}
