// Script de la página del carrito
// Muestra los productos guardados, permite cambiar cantidades, eliminar y ver el total.
// La lectura y escritura del carrito está en carrito.js

import { obtenerCarrito, cambiarCantidad, eliminarDelCarrito, calcularTotal } from "./carrito.js";
import { formatearPrecio } from "./formato.js";
import { mostrarEstado, mostrarNotificacion, actualizarIndicadorCarrito } from "./interfaz.js";

const CANTIDAD_MAXIMA = 99;

// ---------- Dibujar ----------

// Crea el bloque (<article>) de un producto del carrito
function crearArticuloCarrito(item) {
    const articulo = document.createElement("article");
    articulo.className = "item-carrito";

    articulo.innerHTML = `
        <picture>
            <img src="${item.imagen}" alt="${item.nombre}">
        </picture>
        <p>${item.nombre}</p>
        <label for="cant-${item.id}">Cantidad</label>
        <input type="number" id="cant-${item.id}" class="input-cantidad" data-id="${item.id}" value="${item.cantidad}" min="1" max="${CANTIDAD_MAXIMA}">
        <p>Precio ${formatearPrecio(item.precio * item.cantidad)}</p>
        <button class="boton-secundario" type="button" data-id="${item.id}">Eliminar</button>
    `;

    return articulo;
}

// Dibuja la lista de productos (o el mensaje de carrito vacío)
function mostrarProductos(carrito) {
    const contenedor = document.querySelector(".carrito-productos");

    if (carrito.length === 0) {
        mostrarEstado(contenedor, "Tu carrito está vacío.", [{ texto: "Ir al catálogo", href: "./catalogo.html" }]);
        return;
    }

    contenedor.innerHTML = "";

    carrito.forEach(function (item) {
        contenedor.appendChild(crearArticuloCarrito(item));
    });
}

// Dibuja el resumen del pedido con el total
function mostrarResumen(total) {
    const listaResumen = document.querySelector(".resumen-pedido ul");

    listaResumen.innerHTML = `
        <li>Subtotal ${formatearPrecio(total)}</li>
        <li>Envío Gratis</li>
        <li>Total ${formatearPrecio(total)}</li>
    `;
}

// Vuelve a leer el carrito guardado y actualiza toda la pantalla
function actualizarVista() {
    const carrito = obtenerCarrito();

    mostrarProductos(carrito);
    mostrarResumen(calcularTotal(carrito));
    actualizarIndicadorCarrito();
}

// ---------- Eventos ----------

// Cuando se modifica la cantidad en un input
function manejarCambioDeCantidad(evento) {
    if (!evento.target.classList.contains("input-cantidad")) {
        return;
    }

    const nuevaCantidad = parseInt(evento.target.value);

    if (!Number.isInteger(nuevaCantidad) || nuevaCantidad < 1 || nuevaCantidad > CANTIDAD_MAXIMA) {
        mostrarNotificacion("La cantidad debe estar entre 1 y " + CANTIDAD_MAXIMA + ".", "warning");
        actualizarVista();
        return;
    }

    cambiarCantidad(evento.target.dataset.id, nuevaCantidad);
    actualizarVista();
}

// Cuando se hace click en "Eliminar"
function manejarClickEliminar(evento) {
    if (evento.target.tagName !== "BUTTON") {
        return;
    }

    const id = evento.target.dataset.id;
    const item = obtenerCarrito().find(function (producto) {
        return producto.id === id;
    });

    eliminarDelCarrito(id);
    actualizarVista();

    if (item) {
        mostrarNotificacion(item.nombre + " se eliminó del carrito.", "info");
    }
}

// Al presionar "Proceder al pago": si el carrito está vacío, avisamos y no seguimos
function manejarProcederAlPago(evento) {
    if (obtenerCarrito().length === 0) {
        evento.preventDefault();
        mostrarNotificacion("Agregá productos al carrito para continuar.", "warning");
    }
}

// ---------- Inicio ----------

function iniciar() {
    const contenedor = document.querySelector(".carrito-productos");
    const formulario = document.querySelector(".formulario-carrito");

    contenedor.addEventListener("change", manejarCambioDeCantidad);
    contenedor.addEventListener("click", manejarClickEliminar);
    formulario.addEventListener("submit", manejarProcederAlPago);

    actualizarVista();
}

iniciar();
