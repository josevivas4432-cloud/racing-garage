// Configuración general del sitio
// Todo lo que se puede querer cambiar (rutas, número de WhatsApp, descuentos) está acá.

export const NOMBRE_TIENDA = "Racing Garage";

// Ruta del archivo JSON con los productos (se lee con fetch)
export const RUTA_PRODUCTOS = "./recursos/data/productos.json";

// Número de WhatsApp que recibe los pedidos y mensajes.
// Formato internacional, solo números, sin "+" ni espacios. Ej: Argentina (Córdoba): "5493511234567"
// Si queda vacío, WhatsApp deja elegir a qué contacto enviar el mensaje.
export const NUMERO_WHATSAPP = "";

// Descuento por pagar con transferencia bancaria (0.10 = 10 %)
export const DESCUENTO_TRANSFERENCIA = 0.10;
