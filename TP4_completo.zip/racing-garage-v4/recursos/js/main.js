// Script general (inicio y nosotros)
// Estas páginas no tienen lógica propia: solo muestran en el menú cuántas unidades hay en el carrito.

import { actualizarIndicadorCarrito } from "./interfaz.js";

actualizarIndicadorCarrito();
