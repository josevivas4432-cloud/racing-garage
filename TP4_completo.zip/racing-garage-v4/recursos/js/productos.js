// Módulo de productos
// Lee el archivo JSON con fetch y lo deja disponible para el resto de los scripts.

import { RUTA_PRODUCTOS } from "./config.js";

// Guardamos los productos una vez leídos para no pedir el archivo de nuevo en cada uso
let productosEnMemoria = null;

// Pide el archivo JSON y devuelve el arreglo de productos.
// Si algo falla (sin conexión, archivo inexistente, JSON dañado) lanza un error con un mensaje para el usuario.
export async function cargarProductos() {
    if (productosEnMemoria) {
        return productosEnMemoria;
    }

    try {
        const respuesta = await fetch(RUTA_PRODUCTOS);

        if (!respuesta.ok) {
            throw new Error("Respuesta HTTP " + respuesta.status);
        }

        const datos = await respuesta.json();
        productosEnMemoria = datos.productos;
        return productosEnMemoria;
    } catch (error) {
        console.error("No se pudieron cargar los productos:", error);
        throw new Error("No pudimos cargar los productos. Revisá tu conexión e intentá de nuevo.");
    }
}

// Busca un producto por su id dentro de una lista. Devuelve undefined si no existe
export function buscarProductoPorId(lista, id) {
    return lista.find(function (producto) {
        return producto.id === id;
    });
}
