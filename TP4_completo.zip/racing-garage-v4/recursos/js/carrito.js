// Módulo del carrito
// Concentra TODA la lógica que lee o escribe en localStorage (carrito, pedido y producto elegido).
// Los demás scripts importan estas funciones en lugar de repetir el código.

const CLAVE_CARRITO = "carrito";
const CLAVE_ULTIMO_PEDIDO = "ultimo_pedido";
const CLAVE_PRODUCTO_SELECCIONADO = "producto_seleccionado";

// ---------- Acceso a localStorage (con manejo de errores) ----------

// Lee un valor guardado como JSON. Si no existe o está dañado, devuelve el valor por defecto
function leerDeLocalStorage(clave, valorPorDefecto) {
    try {
        const guardado = localStorage.getItem(clave);
        return guardado ? JSON.parse(guardado) : valorPorDefecto;
    } catch (error) {
        console.error("No se pudo leer '" + clave + "' de localStorage:", error);
        return valorPorDefecto;
    }
}

// Guarda un valor como JSON. Devuelve true si se pudo guardar y false si falló
function guardarEnLocalStorage(clave, valor) {
    try {
        localStorage.setItem(clave, JSON.stringify(valor));
        return true;
    } catch (error) {
        console.error("No se pudo guardar '" + clave + "' en localStorage:", error);
        return false;
    }
}

// ---------- Carrito ----------

// Devuelve el carrito guardado (un array). Si no hay nada guardado, devuelve un array vacío
export function obtenerCarrito() {
    return leerDeLocalStorage(CLAVE_CARRITO, []);
}

export function guardarCarrito(carrito) {
    return guardarEnLocalStorage(CLAVE_CARRITO, carrito);
}

export function vaciarCarrito() {
    try {
        localStorage.removeItem(CLAVE_CARRITO);
    } catch (error) {
        console.error("No se pudo vaciar el carrito:", error);
    }
}

// Agrega un producto al carrito. Si ya estaba, le suma la cantidad. Devuelve true si se guardó
export function agregarAlCarrito(producto, cantidad) {
    const carrito = obtenerCarrito();
    const itemExistente = carrito.find(function (item) {
        return item.id === producto.id;
    });

    if (itemExistente) {
        itemExistente.cantidad = itemExistente.cantidad + cantidad;
    } else {
        carrito.push({
            id: producto.id,
            nombre: producto.nombre,
            precio: producto.precio,
            imagen: producto.imagen,
            cantidad: cantidad
        });
    }

    return guardarCarrito(carrito);
}

// Cambia la cantidad de un producto que ya está en el carrito
export function cambiarCantidad(idProducto, nuevaCantidad) {
    const carrito = obtenerCarrito();

    carrito.forEach(function (item) {
        if (item.id === idProducto) {
            item.cantidad = nuevaCantidad;
        }
    });

    guardarCarrito(carrito);
}

// Quita un producto del carrito
export function eliminarDelCarrito(idProducto) {
    const carrito = obtenerCarrito().filter(function (item) {
        return item.id !== idProducto;
    });

    guardarCarrito(carrito);
}

// Calcula el total de una lista de ítems (precio x cantidad de cada uno)
export function calcularTotal(items) {
    let total = 0;

    items.forEach(function (item) {
        total = total + item.precio * item.cantidad;
    });

    return total;
}

// Cuenta cuántas unidades hay en total (para el número del ícono del carrito)
export function contarUnidades(items) {
    let unidades = 0;

    items.forEach(function (item) {
        unidades = unidades + item.cantidad;
    });

    return unidades;
}

// ---------- Pedido ----------

export function guardarUltimoPedido(pedido) {
    return guardarEnLocalStorage(CLAVE_ULTIMO_PEDIDO, pedido);
}

// Devuelve el último pedido confirmado, o null si no hay ninguno
export function obtenerUltimoPedido() {
    return leerDeLocalStorage(CLAVE_ULTIMO_PEDIDO, null);
}

// ---------- Producto elegido en el catálogo ----------

export function guardarIdProductoSeleccionado(idProducto) {
    try {
        localStorage.setItem(CLAVE_PRODUCTO_SELECCIONADO, idProducto);
    } catch (error) {
        console.error("No se pudo guardar el producto elegido:", error);
    }
}

export function obtenerIdProductoSeleccionado() {
    try {
        return localStorage.getItem(CLAVE_PRODUCTO_SELECCIONADO);
    } catch (error) {
        return null;
    }
}
