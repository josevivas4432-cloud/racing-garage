// Script del detalle de producto
// Muestra el producto que el usuario eligió en el catálogo y permite agregarlo al carrito.
// Cada paso está en una función con un nombre que explica qué hace.

import { cargarProductos, buscarProductoPorId } from "./productos.js";
import { agregarAlCarrito, obtenerIdProductoSeleccionado } from "./carrito.js";
import { formatearPrecio } from "./formato.js";
import { mostrarEstado, mostrarNotificacion, actualizarIndicadorCarrito } from "./interfaz.js";

// ---------- Buscar el producto ----------

// Devuelve el producto elegido en el catálogo. Si no hay ninguno guardado, usa el primero
function obtenerProductoSeleccionado(productos) {
    const idSeleccionado = obtenerIdProductoSeleccionado();
    return buscarProductoPorId(productos, idSeleccionado) || productos[0];
}

// ---------- Mostrar el producto en pantalla ----------

// Crea un <li> con el texto indicado
function crearItemDeLista(texto) {
    const item = document.createElement("li");
    item.textContent = texto;
    return item;
}

// Completa la lista con las especificaciones del producto y, al final, su precio
function mostrarEspecificaciones(producto) {
    const lista = document.querySelector(".detalle-producto > ul");
    lista.innerHTML = "";

    producto.especificaciones.forEach(function (especificacion) {
        lista.appendChild(crearItemDeLista(especificacion));
    });

    lista.appendChild(crearItemDeLista("Precio " + formatearPrecio(producto.precio)));
}

// Completa el título, la imagen, la descripción y la lista con los datos del producto
function mostrarProducto(producto) {
    const titulo = document.querySelector(".detalle-producto h1");
    const imagen = document.querySelector(".detalle-producto picture img");
    const descripcion = document.querySelector(".detalle-producto > p");

    document.title = "Racing Garage - " + producto.nombre;
    titulo.textContent = producto.nombre;
    imagen.src = producto.imagen;
    imagen.alt = producto.nombre;
    descripcion.textContent = producto.descripcionLarga;

    mostrarEspecificaciones(producto);
}

// ---------- Agregar al carrito ----------

// Una cantidad es válida si es un número entero mayor o igual a 1
function esCantidadValida(cantidad) {
    return Number.isInteger(cantidad) && cantidad >= 1;
}

// Se ejecuta al enviar el formulario "Agregar al carrito"
function manejarAgregarAlCarrito(evento, producto) {
    evento.preventDefault();

    const inputCantidad = document.querySelector("#id-cantidad");
    const cantidad = parseInt(inputCantidad.value);

    if (!esCantidadValida(cantidad)) {
        mostrarNotificacion("La cantidad debe ser mayor a 0.", "warning");
        return;
    }

    if (!agregarAlCarrito(producto, cantidad)) {
        mostrarNotificacion("No pudimos guardar el carrito en tu navegador.", "error");
        return;
    }

    actualizarIndicadorCarrito();
    mostrarNotificacion(cantidad + " unidad(es) de " + producto.nombre + " agregadas al carrito.");
}

// ---------- Inicio ----------

async function iniciar() {
    const pagina = document.querySelector(".detalle-producto");
    const formulario = document.querySelector(".formulario-agregar");

    actualizarIndicadorCarrito();

    try {
        const productos = await cargarProductos();
        const producto = obtenerProductoSeleccionado(productos);

        mostrarProducto(producto);

        formulario.addEventListener("submit", function (evento) {
            manejarAgregarAlCarrito(evento, producto);
        });
    } catch (error) {
        mostrarEstado(pagina, error.message, [{ texto: "Volver al catálogo", href: "./catalogo.html" }]);
        mostrarNotificacion(error.message, "error");
    }
}

iniciar();
