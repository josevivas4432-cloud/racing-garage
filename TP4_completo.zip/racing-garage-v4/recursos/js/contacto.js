// Script del formulario de contacto
// Valida los datos y abre WhatsApp con la consulta lista para enviar

import { validarFormulario, activarValidacionEnVivo, limpiarErrores } from "./validaciones.js";
import { construirMensajeDeContacto, abrirWhatsApp } from "./whatsapp.js";
import { mostrarNotificacion, actualizarIndicadorCarrito } from "./interfaz.js";

// Lee los valores que el usuario escribió en el formulario
function leerDatosDeContacto() {
    return {
        nombre: document.querySelector("#id-nombre").value.trim(),
        email: document.querySelector("#id-email").value.trim(),
        mensaje: document.querySelector("#id-mensaje").value.trim()
    };
}

// Se ejecuta al enviar el formulario
function manejarEnvioDeContacto(evento) {
    evento.preventDefault();

    const formulario = evento.target;

    if (!validarFormulario(formulario)) {
        mostrarNotificacion("Revisá los campos marcados en rojo.", "error");
        return;
    }

    const datos = leerDatosDeContacto();

    if (abrirWhatsApp(construirMensajeDeContacto(datos))) {
        mostrarNotificacion("¡Gracias " + datos.nombre + "! Abrimos WhatsApp con tu mensaje para que lo envíes.");
    } else {
        mostrarNotificacion("Tu navegador bloqueó la ventana de WhatsApp. Permití las ventanas emergentes e intentá de nuevo.", "warning");
        return;
    }

    formulario.reset();
    limpiarErrores(formulario);
}

// ---------- Inicio ----------

function iniciar() {
    const formulario = document.querySelector(".formulario");

    formulario.addEventListener("submit", manejarEnvioDeContacto);
    activarValidacionEnVivo(formulario);
    actualizarIndicadorCarrito();
}

iniciar();
