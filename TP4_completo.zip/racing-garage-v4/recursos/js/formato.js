// Módulo de formato: funciones chicas para mostrar datos de la misma manera en todo el sitio

// Recibe un número y lo devuelve con separador de miles argentino. Ej: 1249 -> "1.249"
export function formatearNumero(valor) {
    return valor.toLocaleString("es-AR");
}

// Recibe un número y lo devuelve como precio. Ej: 1249 -> "$ 1.249"
export function formatearPrecio(valor) {
    return "$ " + formatearNumero(valor);
}

// Escapa los caracteres especiales de HTML. Se usa con lo que escribe el usuario
// antes de insertarlo con innerHTML, para que no se interprete como código.
export function escaparHtml(texto) {
    return String(texto)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
