// Script del formulario de finalizar compra
// Valida los datos, arma el pedido, lo guarda, lo envía por WhatsApp y redirige a la confirmación

import { obtenerCarrito, vaciarCarrito, guardarUltimoPedido } from "./carrito.js";
import { calcularTotales, armarPedido } from "./pedido.js";
import { validarFormulario, activarValidacionEnVivo } from "./validaciones.js";
import { construirMensajeDePedido, abrirWhatsApp } from "./whatsapp.js";
import { mostrarNotificacion, actualizarIndicadorCarrito } from "./interfaz.js";
import { formatearPrecio } from "./formato.js";

// ---------- Leer el formulario ----------

function leerMetodoDePago() {
    return document.querySelector('input[name="metodo-pago"]:checked').value;
}

// Lee los datos de envío que escribió el usuario
function leerDatosDelCliente() {
    return {
        nombre: document.querySelector("#id-nombre").value.trim(),
        email: document.querySelector("#id-email").value.trim(),
        telefono: document.querySelector("#id-telefono").value.trim(),
        direccion: document.querySelector("#id-direccion").value.trim(),
        ciudad: document.querySelector("#id-ciudad").value.trim(),
        codigoPostal: document.querySelector("#id-codigo-postal").value.trim()
    };
}

// ---------- Resumen del pedido ----------

// Crea un <li> con una etiqueta a la izquierda y un valor a la derecha
function crearLineaDeResumen(etiqueta, valor) {
    const linea = document.createElement("li");
    const textoEtiqueta = document.createElement("span");
    const textoValor = document.createElement("span");

    textoEtiqueta.textContent = etiqueta;
    textoValor.textContent = valor;
    linea.append(textoEtiqueta, " ", textoValor);

    return linea;
}

// Dibuja el resumen con los totales del carrito según el método de pago elegido
function mostrarResumen() {
    const lista = document.querySelector(".resumen-lista");
    const totales = calcularTotales(obtenerCarrito(), leerMetodoDePago());

    lista.innerHTML = "";
    lista.appendChild(crearLineaDeResumen("Subtotal", formatearPrecio(totales.subtotal)));

    if (totales.descuento > 0) {
        lista.appendChild(crearLineaDeResumen("Descuento por transferencia", "-" + formatearPrecio(totales.descuento)));
    }

    lista.appendChild(crearLineaDeResumen("Envío", "Gratis"));
    lista.appendChild(crearLineaDeResumen("Total", formatearPrecio(totales.total)));
}

// ---------- Confirmar la compra ----------

// Se ejecuta al enviar el formulario
function manejarConfirmarCompra(evento) {
    evento.preventDefault();

    const carrito = obtenerCarrito();

    if (carrito.length === 0) {
        mostrarNotificacion("Tu carrito está vacío. No podés confirmar una compra sin productos.", "warning");
        return;
    }

    if (!validarFormulario(evento.target)) {
        mostrarNotificacion("Revisá los campos marcados en rojo.", "error");
        return;
    }

    const pedido = armarPedido(leerDatosDelCliente(), leerMetodoDePago(), carrito);

    if (!guardarUltimoPedido(pedido)) {
        mostrarNotificacion("No pudimos guardar tu pedido en el navegador. Intentá de nuevo.", "error");
        return;
    }

    // Abrimos WhatsApp con el pedido listo para enviar (si el navegador lo bloquea, hay un botón en la confirmación)
    abrirWhatsApp(construirMensajeDePedido(pedido));

    vaciarCarrito();
    window.location.href = "./confirmacion.html";
}

// ---------- Inicio ----------

function iniciar() {
    const formulario = document.querySelector(".formulario");

    formulario.addEventListener("submit", manejarConfirmarCompra);
    formulario.addEventListener("change", function (evento) {
        if (evento.target.name === "metodo-pago") {
            mostrarResumen();
        }
    });

    activarValidacionEnVivo(formulario);
    actualizarIndicadorCarrito();
    mostrarResumen();

    if (obtenerCarrito().length === 0) {
        mostrarNotificacion("Tu carrito está vacío. Agregá productos para poder comprar.", "warning");
    }
}

iniciar();
