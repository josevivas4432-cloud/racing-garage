// Módulo de interfaz: avisos en pantalla, indicador del carrito y mensajes de estado.
// Reemplaza a los alert() del navegador por notificaciones dentro de la página.

import { obtenerCarrito, contarUnidades } from "./carrito.js";

const DURACION_NOTIFICACION = 3500; // milisegundos que se ve el aviso
let temporizadorNotificacion = null;

// ---------- Notificaciones ----------

// Devuelve el aviso flotante; si todavía no existe en la página, lo crea
function obtenerElementoNotificacion() {
    let notificacion = document.querySelector(".notificacion-toast");

    if (!notificacion) {
        notificacion = document.createElement("div");
        notificacion.className = "notificacion-toast";
        notificacion.setAttribute("role", "status");
        notificacion.setAttribute("aria-live", "polite");
        document.body.appendChild(notificacion);
    }

    return notificacion;
}

// Muestra un aviso unos segundos. tipo: "exito" (por defecto), "info", "warning" o "error"
export function mostrarNotificacion(mensaje, tipo = "exito") {
    const notificacion = obtenerElementoNotificacion();

    notificacion.className = "notificacion-toast";
    if (tipo !== "exito") {
        notificacion.classList.add("notificacion-" + tipo);
    }

    notificacion.textContent = mensaje;
    // Leer una propiedad fuerza al navegador a aplicar los estilos antes de la animación
    notificacion.getBoundingClientRect();
    notificacion.classList.add("notificacion-visible");

    clearTimeout(temporizadorNotificacion);
    temporizadorNotificacion = setTimeout(function () {
        notificacion.classList.remove("notificacion-visible");
    }, DURACION_NOTIFICACION);
}

// ---------- Indicador del carrito ----------

// Muestra en el menú cuántas unidades hay en el carrito. Si está vacío, no muestra nada
export function actualizarIndicadorCarrito() {
    const enlaceCarrito = document.querySelector('nav a[href="./carrito.html"]');

    if (!enlaceCarrito) {
        return;
    }

    const unidades = contarUnidades(obtenerCarrito());
    let indicador = enlaceCarrito.querySelector(".badge-carrito");

    if (unidades === 0) {
        if (indicador) {
            indicador.remove();
        }
        return;
    }

    if (!indicador) {
        indicador = document.createElement("span");
        indicador.className = "badge-carrito";
        enlaceCarrito.appendChild(indicador);
    }

    indicador.textContent = unidades;
    indicador.setAttribute("aria-label", unidades + " unidades en el carrito");
}

// ---------- Mensajes de estado dentro de un contenedor ----------

// Reemplaza el contenido del contenedor por un mensaje con acciones opcionales.
// acciones: lista de { texto, href } para enlaces o { texto, alHacerClick } para botones
export function mostrarEstado(contenedor, mensaje, acciones = []) {
    contenedor.innerHTML = "";

    const caja = document.createElement("div");
    caja.className = "mensaje-vacio";

    const texto = document.createElement("p");
    texto.textContent = mensaje;
    caja.appendChild(texto);

    acciones.forEach(function (accion) {
        if (accion.href) {
            const enlace = document.createElement("a");
            enlace.className = "boton-principal";
            enlace.href = accion.href;
            enlace.textContent = accion.texto;
            caja.appendChild(enlace);
        } else {
            const boton = document.createElement("button");
            boton.className = "boton-principal";
            boton.type = "button";
            boton.textContent = accion.texto;
            boton.addEventListener("click", accion.alHacerClick);
            caja.appendChild(boton);
        }
    });

    contenedor.appendChild(caja);
}
