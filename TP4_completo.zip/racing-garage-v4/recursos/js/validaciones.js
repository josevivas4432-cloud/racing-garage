// Módulo de validaciones de formularios (capa de JavaScript)
// El HTML ya valida con required, type, pattern y minlength. Acá se suman reglas más estrictas
// (por ejemplo, rechazar campos con solo espacios) y se muestra el error debajo de cada campo.

// Reglas por id de campo: esValido recibe el texto y devuelve true/false
const REGLAS = {
    "id-nombre": {
        mensaje: "Ingresá tu nombre completo (solo letras, mínimo 3 caracteres).",
        esValido: function (valor) {
            return /^[\p{L}][\p{L}\s'.-]{2,59}$/u.test(valor.trim());
        }
    },
    "id-email": {
        mensaje: "Ingresá un email válido. Ej: juan@ejemplo.com",
        esValido: function (valor) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(valor.trim());
        }
    },
    "id-telefono": {
        mensaje: "Ingresá un teléfono válido, de 8 a 13 números. Ej: 3511234567",
        esValido: function (valor) {
            const soloNumeros = valor.replace(/[\s()+-]/g, "");
            return /^\d{8,13}$/.test(soloNumeros);
        }
    },
    "id-direccion": {
        mensaje: "Ingresá calle y número (mínimo 5 caracteres).",
        esValido: function (valor) {
            return valor.trim().length >= 5;
        }
    },
    "id-ciudad": {
        mensaje: "Ingresá tu ciudad (mínimo 2 letras).",
        esValido: function (valor) {
            return /^[\p{L}][\p{L}\s.'-]{1,59}$/u.test(valor.trim());
        }
    },
    "id-codigo-postal": {
        mensaje: "El código postal debe tener 4 números. Ej: 5000",
        esValido: function (valor) {
            return /^\d{4}$/.test(valor.trim());
        }
    },
    "id-mensaje": {
        mensaje: "Escribí un mensaje de al menos 10 caracteres.",
        esValido: function (valor) {
            return valor.trim().length >= 10;
        }
    }
};

// Devuelve el texto del error de un campo, o "" si está bien
function obtenerMensajeDeError(campo) {
    const regla = REGLAS[campo.id];

    if (!regla) {
        return "";
    }

    if (campo.value.trim() === "") {
        return "Este campo es obligatorio.";
    }

    return regla.esValido(campo.value) ? "" : regla.mensaje;
}

// Devuelve el <span> donde se escribe el error del campo; si no existe, lo crea debajo del campo
function obtenerZonaDeError(campo) {
    const idError = "error-" + campo.id;
    let zona = document.getElementById(idError);

    if (!zona) {
        zona = document.createElement("span");
        zona.id = idError;
        zona.className = "error-campo";
        zona.setAttribute("role", "alert");
        campo.insertAdjacentElement("afterend", zona);
        campo.setAttribute("aria-describedby", idError);
    }

    return zona;
}

// Muestra (o borra, si el mensaje está vacío) el error de un campo
function mostrarErrorEnCampo(campo, mensaje) {
    const zona = obtenerZonaDeError(campo);

    zona.textContent = mensaje;

    if (mensaje) {
        campo.setAttribute("aria-invalid", "true");
    } else {
        campo.removeAttribute("aria-invalid");
    }
}

// Devuelve los campos del formulario que tienen una regla definida
function obtenerCamposValidables(formulario) {
    return Array.from(formulario.querySelectorAll("input, textarea")).filter(function (campo) {
        return REGLAS[campo.id];
    });
}

// Valida un solo campo y muestra su error. Devuelve true si está bien
export function validarCampo(campo) {
    const mensaje = obtenerMensajeDeError(campo);
    mostrarErrorEnCampo(campo, mensaje);
    return mensaje === "";
}

// Valida todo el formulario. Si hay errores, los muestra y deja el foco en el primer campo con error
export function validarFormulario(formulario) {
    let primerCampoInvalido = null;

    obtenerCamposValidables(formulario).forEach(function (campo) {
        const esValido = validarCampo(campo);

        if (!esValido && !primerCampoInvalido) {
            primerCampoInvalido = campo;
        }
    });

    if (primerCampoInvalido) {
        primerCampoInvalido.focus();
    }

    return primerCampoInvalido === null;
}

// Valida cada campo apenas el usuario sale de él (blur) y, si ya tenía error, mientras escribe
export function activarValidacionEnVivo(formulario) {
    obtenerCamposValidables(formulario).forEach(function (campo) {
        campo.addEventListener("blur", function () {
            validarCampo(campo);
        });

        campo.addEventListener("input", function () {
            if (campo.getAttribute("aria-invalid") === "true") {
                validarCampo(campo);
            }
        });
    });
}

// Borra todos los errores del formulario (por ejemplo, después de enviarlo)
export function limpiarErrores(formulario) {
    obtenerCamposValidables(formulario).forEach(function (campo) {
        mostrarErrorEnCampo(campo, "");
    });
}
