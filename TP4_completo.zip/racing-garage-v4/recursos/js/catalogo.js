// Script del catálogo: lee los productos desde el JSON, dibuja las tarjetas y filtra por marca y categoría

import { cargarProductos } from "./productos.js";
import { guardarIdProductoSeleccionado } from "./carrito.js";
import { formatearPrecio } from "./formato.js";
import { mostrarEstado, mostrarNotificacion, actualizarIndicadorCarrito } from "./interfaz.js";

// Lista completa de productos, una vez cargada desde el JSON
let todosLosProductos = [];

// ---------- Dibujar productos ----------

// Crea la tarjeta (<article>) de un producto
function crearTarjetaProducto(producto) {
    const tarjeta = document.createElement("article");
    tarjeta.className = "tarjeta-producto";

    tarjeta.innerHTML = `
        <h3>${producto.nombre}</h3>
        <picture>
            <img src="${producto.imagen}" alt="${producto.nombre}">
        </picture>
        <p>${producto.descripcionCorta}</p>
        <ul>
            <li>${producto.caracteristica}</li>
            <li>Precio ${formatearPrecio(producto.precio)}</li>
        </ul>
        <a class="boton-principal" href="./producto.html" data-id="${producto.id}">Ver más</a>
    `;

    return tarjeta;
}

// Recibe una lista de productos y los dibuja en el contenedor del catálogo
function mostrarProductos(lista) {
    const contenedor = document.querySelector(".catalogo-productos");

    if (lista.length === 0) {
        mostrarEstado(contenedor, "No se encontraron productos con esos filtros.");
        return;
    }

    contenedor.innerHTML = "";

    lista.forEach(function (producto) {
        contenedor.appendChild(crearTarjetaProducto(producto));
    });
}

// ---------- Filtrar ----------

// Devuelve los productos que coinciden con la marca y la categoría (un valor vacío significa "todas")
function filtrarPorMarcaYCategoria(marca, categoria) {
    return todosLosProductos.filter(function (producto) {
        const coincideMarca = marca === "" || producto.marca === marca;
        const coincideCategoria = categoria === "" || producto.categoria === categoria;
        return coincideMarca && coincideCategoria;
    });
}

// Lee lo que eligió el usuario en los desplegables y muestra los productos filtrados
function aplicarFiltros() {
    const marca = document.querySelector("#id-marca").value;
    const categoria = document.querySelector("#id-categoria").value;

    mostrarProductos(filtrarPorMarcaYCategoria(marca, categoria));
}

// Si llegamos desde la portada con ?categoria=..., deja elegida esa categoría en el desplegable
function elegirCategoriaDesdeUrl() {
    const categoria = new URLSearchParams(window.location.search).get("categoria");

    if (categoria) {
        document.querySelector("#id-categoria").value = categoria;
    }
}

// ---------- Ver más ----------

// Cuando se hace click en "Ver más" guardamos el id del producto para mostrarlo en producto.html
function manejarClickVerMas(evento) {
    if (evento.target.tagName === "A") {
        guardarIdProductoSeleccionado(evento.target.dataset.id);
    }
}

// ---------- Carga de datos ----------

// Pide los productos al JSON. Si falla, muestra el error en pantalla con un botón para reintentar
async function cargarCatalogo() {
    const contenedor = document.querySelector(".catalogo-productos");
    mostrarEstado(contenedor, "Cargando productos...");

    try {
        todosLosProductos = await cargarProductos();
        elegirCategoriaDesdeUrl();
        aplicarFiltros();
    } catch (error) {
        mostrarEstado(contenedor, error.message, [{ texto: "Reintentar", alHacerClick: cargarCatalogo }]);
        mostrarNotificacion(error.message, "error");
    }
}

// ---------- Inicio ----------

function iniciar() {
    const formularioFiltros = document.querySelector(".filtros-catalogo");
    const contenedor = document.querySelector(".catalogo-productos");

    formularioFiltros.addEventListener("submit", function (evento) {
        evento.preventDefault();
        aplicarFiltros();
    });

    // También filtramos apenas cambia alguno de los desplegables
    document.querySelector("#id-marca").addEventListener("change", aplicarFiltros);
    document.querySelector("#id-categoria").addEventListener("change", aplicarFiltros);

    contenedor.addEventListener("click", manejarClickVerMas);

    actualizarIndicadorCarrito();
    cargarCatalogo();
}

iniciar();
