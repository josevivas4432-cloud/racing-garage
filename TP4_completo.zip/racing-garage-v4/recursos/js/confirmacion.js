// Script de la página de confirmación de compra
// Muestra el recibo del último pedido guardado y el botón para enviarlo por WhatsApp

import { obtenerUltimoPedido } from "./carrito.js";
import { formatearPrecio, escaparHtml } from "./formato.js";
import { NOMBRES_METODO_DE_PAGO } from "./pedido.js";
import { construirMensajeDePedido, construirLinkDeWhatsApp } from "./whatsapp.js";
import { mostrarEstado, mostrarNotificacion, actualizarIndicadorCarrito } from "./interfaz.js";

// Arma la lista de productos del recibo (<li> con nombre y subtotal)
function crearHtmlProductos(productos) {
    let html = "";

    productos.forEach(function (item) {
        html += "<li><span>" + escaparHtml(item.nombre) + " x" + item.cantidad + "</span><span>"
            + formatearPrecio(item.precio * item.cantidad) + "</span></li>";
    });

    return html;
}

// Dibuja el recibo completo del pedido
function mostrarPedido(pedido) {
    const contenedor = document.querySelector(".mensaje-confirmacion");
    const cliente = pedido.cliente;
    const totales = pedido.totales;
    const lineaDescuento = totales.descuento > 0
        ? "<p>Descuento por transferencia: -" + formatearPrecio(totales.descuento) + "</p>"
        : "";

    contenedor.innerHTML = `
        <h1>¡Gracias por tu compra, ${escaparHtml(cliente.nombre)}!</h1>
        <p>Tu pedido fue registrado correctamente.</p>
        <p class="codigo-orden">Número de pedido: <strong>${pedido.codigo}</strong></p>

        <section class="detalle-orden-confirmada" aria-labelledby="titulo-recibo">
            <h2 id="titulo-recibo">Detalle de tu pedido</h2>
            <ul class="lista-items-orden">${crearHtmlProductos(pedido.productos)}</ul>
            <p>Subtotal: ${formatearPrecio(totales.subtotal)}</p>
            ${lineaDescuento}
            <p>Envío: Gratis</p>
            <p class="total-orden">Total: ${formatearPrecio(totales.total)}</p>
            <p class="separador-resumen"><strong>Envío a:</strong> ${escaparHtml(cliente.direccion)}, ${escaparHtml(cliente.ciudad)} (CP ${escaparHtml(cliente.codigoPostal)})</p>
            <p><strong>Pago:</strong> ${NOMBRES_METODO_DE_PAGO[pedido.metodoDePago]}</p>
        </section>

        <p class="aviso-envio">Si no se abrió WhatsApp con tu pedido, enviálo desde este botón.</p>
        <a class="boton-whatsapp" href="${construirLinkDeWhatsApp(construirMensajeDePedido(pedido))}" target="_blank" rel="noopener noreferrer">Enviar pedido por WhatsApp</a>
        <a class="boton-principal" href="./index.html">Volver al inicio</a>
    `;
}

// Avisa que el pedido se registró, una sola vez por pedido (aunque se recargue la página)
function avisarPedidoRegistrado(pedido) {
    try {
        if (sessionStorage.getItem("pedido_notificado") === pedido.codigo) {
            return;
        }
        sessionStorage.setItem("pedido_notificado", pedido.codigo);
    } catch (error) {
        // Si sessionStorage no está disponible, igual mostramos el aviso
    }

    mostrarNotificacion("Pedido " + pedido.codigo + " registrado correctamente.");
}

// ---------- Inicio ----------

function iniciar() {
    const contenedor = document.querySelector(".mensaje-confirmacion");
    const pedido = obtenerUltimoPedido();

    actualizarIndicadorCarrito();

    if (!pedido) {
        mostrarEstado(contenedor, "No hay ningún pedido reciente para mostrar.", [{ texto: "Ir al catálogo", href: "./catalogo.html" }]);
        return;
    }

    mostrarPedido(pedido);
    avisarPedidoRegistrado(pedido);
}

iniciar();
