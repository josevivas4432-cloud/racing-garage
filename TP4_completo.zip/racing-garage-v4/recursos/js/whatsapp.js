// Módulo de WhatsApp: arma el mensaje y abre WhatsApp con el texto ya escrito

import { NUMERO_WHATSAPP, NOMBRE_TIENDA } from "./config.js";
import { formatearPrecio } from "./formato.js";
import { NOMBRES_METODO_DE_PAGO } from "./pedido.js";

// Arma el texto del pedido para enviar por WhatsApp
export function construirMensajeDePedido(pedido) {
    const cliente = pedido.cliente;
    const lineasProductos = pedido.productos.map(function (item) {
        return "- " + item.nombre + " x" + item.cantidad + " = " + formatearPrecio(item.precio * item.cantidad);
    });

    const lineas = [
        "*Nuevo pedido " + NOMBRE_TIENDA + "* (" + pedido.codigo + ")",
        "",
        "*Cliente:* " + cliente.nombre,
        "*Email:* " + cliente.email,
        "*Teléfono:* " + cliente.telefono,
        "*Envío a:* " + cliente.direccion + ", " + cliente.ciudad + " (CP " + cliente.codigoPostal + ")",
        "*Pago:* " + NOMBRES_METODO_DE_PAGO[pedido.metodoDePago],
        "",
        "*Productos:*",
        ...lineasProductos,
        "",
        "Subtotal: " + formatearPrecio(pedido.totales.subtotal)
    ];

    if (pedido.totales.descuento > 0) {
        lineas.push("Descuento transferencia: -" + formatearPrecio(pedido.totales.descuento));
    }

    lineas.push("Envío: Gratis");
    lineas.push("*Total: " + formatearPrecio(pedido.totales.total) + "*");

    return lineas.join("\n");
}

// Arma el texto de una consulta enviada desde el formulario de contacto
export function construirMensajeDeContacto(datos) {
    return [
        "*Consulta desde la web de " + NOMBRE_TIENDA + "*",
        "",
        "*Nombre:* " + datos.nombre,
        "*Email:* " + datos.email,
        "",
        datos.mensaje
    ].join("\n");
}

// Devuelve el link de WhatsApp con el texto ya cargado
export function construirLinkDeWhatsApp(texto) {
    const numero = NUMERO_WHATSAPP.replace(/\D/g, "");
    return "https://wa.me/" + numero + "?text=" + encodeURIComponent(texto);
}

// Abre WhatsApp en una pestaña nueva. Devuelve false si el navegador bloqueó la ventana
export function abrirWhatsApp(texto) {
    const ventana = window.open(construirLinkDeWhatsApp(texto), "_blank");

    if (!ventana) {
        return false;
    }

    ventana.opener = null;
    return true;
}
